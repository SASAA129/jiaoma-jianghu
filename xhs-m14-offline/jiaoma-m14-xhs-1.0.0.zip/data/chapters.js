// 《椒麻江湖》章节附属数据：背包道具、称号、成就、江湖志线索、新菜卡、终幕卡。数据驱动，策划可直接改文字。
// 条件写法同对白：if（全部为真）/ ifNot（任一为真则不满足）/ ifAny（任一为真即可）。
// icon：素材名（assets 里有图就用图，没有就用 glyph 字画一个圆章）；flip：图标水平翻转（另一半方子复用半张方子的图）。
window.CHAPTERS = {
  "items": [
    { "id": "lingpai", "name": "满家家徽令牌", "glyph": "徽", "desc": "小满随身带着的铜令牌，刻着满家家徽。" },
    { "id": "jinnang", "name": "秘方锦囊", "glyph": "囊", "ifAny": ["end_A", "end_C", "battle_B_win", "ch1_done"], "desc": "红布锦囊，熏得满是椒麻香。" },
    { "id": "zhantie", "name": "辣不怕的战帖", "glyph": "帖", "if": ["end_B"], "desc": "“能吃下十成椒麻者，锦囊奉还。——辣不怕”" },
    { "id": "recipe_half", "name": "半张方子", "icon": "icon_recipe_half", "glyph": "半", "if": ["ch1_done"], "ifNot": ["c2_combined"],
      "desc": "锦囊里只有半张方子，背面写着“渝州·老码头”。" },
    { "id": "recipe_other", "name": "另一半方子", "icon": "icon_recipe_half", "flip": true, "glyph": "半", "if": ["c2_got_half"], "ifNot": ["c2_combined"],
      "desc": "茶馆老板娘守了二十年的另一半。" },
    { "id": "recipe_full", "name": "完整的椒麻秘方", "icon": "icon_recipe_full", "glyph": "方", "if": ["c2_combined"],
      "desc": "两半合璧的满家椒麻秘方。对着灯看，背面似乎还有墨痕。" },
    { "id": "dish", "name": "新菜谱 · 十成椒麻秘制鸡", "glyph": "菜", "if": ["c2_dish"], "desc": "照完整秘方做出的新菜，已上了店里的菜单。" },
    { "id": "treasure_map", "name": "方子背面的藏宝图", "icon": "icon_treasure_map", "glyph": "图", "if": ["c2_finale"], "desc": "江流、山峦，和巫山脚下一个朱砂小圈。" },
    { "id": "iron_box", "name": "锈铁盒", "glyph": "盒", "if": ["item_iron_box"], "ifNot": ["c3_got_pepper"], "desc": "锁扣刻着半个满家家徽，江底捞起。" },
    { "id": "golden_pepper", "name": "金花椒", "icon": "icon_golden_pepper", "glyph": "金", "if": ["c3_got_pepper"], "desc": "满家信物。花椒寨认它。" },
    { "id": "champion", "name": "天下第一锅奖牌", "icon": "icon_golden_pepper", "glyph": "冠", "if": ["item_champion"], "desc": "本届大赛冠军凭证。" },
    { "id": "challenge", "name": "天下第一锅战帖", "icon": "icon_golden_pepper", "glyph": "帖", "if": ["item_challenge"], "desc": "赤老三留下的朱砂战帖：擂台见真章。" },
    { "id": "wild_pepper", "name": "崖顶野椒", "glyph": "野", "if": ["item_wild_pepper"], "desc": "石缝里采下的野椒，今晚开锅用。" },
    { "id": "liangcha", "name": "凉茶", "icon": "icon_liangcha", "glyph": "茶", "count": 3, "desc": "战斗用：回复 300 气血（每场战斗前自动补满）。" },
    { "id": "bingfen", "name": "冰粉", "icon": "icon_bingfen", "glyph": "冰", "count": 2, "desc": "战斗用：回复 200 内力（每场战斗前自动补满）。" }
  ],

  "clues": [
    { "if": ["heard_jinnang"], "text": "满家祖传三代的秘方锦囊，一夜之间不见了。" },
    { "if": ["ch1_done"], "text": "锦囊里只有半张方子，背面写着“渝州·老码头”。爷爷当年和一位故人一人一半。" },
    { "if": ["clue_1"], "text": "【线索一】古玩摊老周：当年当铜牌的是个梳圆髻的姑娘——故人是位女子。" },
    { "if": ["clue_2"], "text": "【线索二】灯谜摊钱先生：那姑娘爱喝老鹰茶，在江边支过茶摊，后来成了茶馆。" },
    { "if": ["clue_3"], "text": "【线索三】辣不怕：每晚有人提着铜茶壶来买椒麻鸡，“给老朋友留着”。" },
    { "if": ["c2_deduced"], "text": "推理：爷爷的故人，就是码头茶馆的老板娘。红汤帮也在打那半张方子的主意。" },
    { "if": ["c2_combined"], "text": "两半方子合璧。老板娘说：“椒麻要配茶，方子要配人。”" },
    { "if": ["c2_finale"], "text": "方子背面藏着一张图：朱砂圈画在巫山脚下。" },
    { "if": ["c3_arrived"], "text": "雾江古渡。船娘阿篙说，满家的人免费送——但要办完三桩事。" },
    { "if": ["c3_e1_done"], "text": "【雾江·星】认准北斗缺口，船头朝东北偏东，避开乱礁。" },
    { "if": ["c3_e2_done"], "text": "【雾江·歌】与阿篙对上三句山歌，船资算清。" },
    { "if": ["c3_e3_done"], "text": "【雾江·网】江底捞起锈铁盒，锁扣刻着半个满家家徽。" },
    { "if": ["c3_ts_win"], "text": "打退红汤帮二当家铁算盘。他撂下话：麻婆岭见。" },
    { "if": ["c3_got_pepper"], "text": "铁盒里有一颗金花椒，纸条写着：“椒源在麻婆岭”。" },
    { "if": ["c4_met_nong"], "text": "老椒农认出金花椒：满家祖上信物。寨里乱着——地界、野椒、开锅三桩事。" },
    { "if": ["c4_e1_done"], "text": "【麻婆岭·界】以椒根年轮定地界，两边各让半垄做公田。" },
    { "if": ["c4_e2_done"], "text": "【麻婆岭·椒】崖顶采下野椒，够今晚开锅。" },
    { "if": ["c4_e3_done"], "text": "【麻婆岭·锅】寨中大锅椒麻鸡出锅，满家手艺没丢。" },
    { "if": ["c4_reformed"], "text": "麻大王供出：红汤帮主在城里总舵大酒楼，手下称他“赤爷”。" },
    { "if": ["c5_inside"], "text": "混进红汤楼。账房、雅座、后厨三条线分头探听。" },
    { "if": ["c5_e1_done"], "text": "【总舵·账】代号「赤爷」，旧名赤老三，满记旧徒。" },
    { "if": ["c5_e2_done"], "text": "【总舵·诗】门客透露：年轻时在满记学艺，后来被逐。" },
    { "if": ["c5_e3_done"], "text": "【总舵·厨】偷锦囊是赤爷亲定，说满记欠他一道方子。" },
    { "if": ["c5_fought"], "text": "大鼎前交手，赤老三逃走，留下「天下第一锅」战帖。" },
    { "if": ["c6_registered"], "text": "报名「天下第一锅」。老友齐聚助阵席。" },
    { "if": ["c6_r1"], "text": "【擂台·方】配方过关，金花椒压得住。" },
    { "if": ["c6_r2"], "text": "【擂台·火】火候稳，油不焦麻不散。" },
    { "if": ["c6_rounds"], "text": "【擂台·勺】三轮胜出。赤老三掀台动手。" },
    { "if": ["c6_final_win"], "text": "擂台决战胜利。赤老三认栽，也认师。" },
    { "if": ["c6_crowned"], "text": "本届「天下第一锅」——满记椒麻鸡火锅！" },
    { "if": ["c6_finale"], "text": "家徽交到小满手里。第四代，从今晚起。" }
  ],

  "titles": [
    { "name": "家徽传人",   "if": ["end_A"],        "desc": "小满线 · 解开家徽机关" },
    { "name": "以扇扇辣",   "if": ["end_B"],        "desc": "飞飞线 · 接下吃辣战帖" },
    { "name": "后厨守护者", "if": ["end_C"],        "desc": "胖弟线 · 抓住偷锦囊的黄猫" },
    { "name": "辣不倒",     "if": ["battle_B_win"], "desc": "招牌下赢了辣不怕" },
    { "name": "认徽有眼",   "if": ["c2_e1_done"],   "desc": "古玩摊认出真家徽" },
    { "name": "灯下舌战",   "if": ["c2_e2_done"],   "desc": "连赢钱先生三阵" },
    { "name": "码头颠勺王", "if": ["c2_e3_done"],   "desc": "帮辣不怕颠出十成辣子鸡" },
    { "name": "红汤克星",   "if": ["c2_ht_win"],    "desc": "打退红汤帮打手" },
    { "name": "秘方传人",   "if": ["c2_finale"],    "desc": "合璧椒麻秘方，解锁新菜" },
    { "name": "雾江识途",   "if": ["c3_e1_done"],   "desc": "桅杆下认出北斗缺口" },
    { "name": "船头歌者",   "if": ["c3_e2_done"],   "desc": "与阿篙对上三句山歌" },
    { "name": "江底捞手",   "if": ["c3_e3_done"],   "desc": "一网捞起满家锈铁盒" },
    { "name": "算盘克星",   "if": ["c3_ts_win"],    "desc": "雾江上打退铁算盘" },
    { "name": "金椒在手",   "if": ["c3_got_pepper"], "desc": "打开铁盒，得金花椒" },
    { "name": "椒田说和",   "if": ["c4_e1_done"],   "desc": "调解东家西家地界" },
    { "name": "崖顶采椒",   "if": ["c4_e2_done"],   "desc": "采下崖顶野椒" },
    { "name": "寨中掌勺",   "if": ["c4_e3_done"],   "desc": "颠出全寨椒麻鸡" },
    { "name": "麻大王克星", "if": ["c4_mw_win"],    "desc": "花椒寨打退麻大王" },
    { "name": "化敌为友·麻", "if": ["c4_reformed"], "desc": "麻大王改邪归正" },
    { "name": "账房一眼",   "if": ["c5_e1_done"],   "desc": "改平假账，看清代号" },
    { "name": "雅座对句",   "if": ["c5_e2_done"],   "desc": "比诗套出旧事" },
    { "name": "后厨帮工",   "if": ["c5_e3_done"],   "desc": "颠勺套出偷囊真相" },
    { "name": "赤汤克星",   "if": ["c5_cl_win"],    "desc": "大鼎前逼退赤老三" },
    { "name": "配方过关",   "if": ["c6_r1"],        "desc": "大赛第一轮配方" },
    { "name": "火候稳准",   "if": ["c6_r2"],        "desc": "大赛第二轮火候" },
    { "name": "颠勺定鼎",   "if": ["c6_r3"],        "desc": "大赛第三轮颠勺" },
    { "name": "擂台定乾坤", "if": ["c6_cf_win"],    "desc": "掀台决战击败赤老三" },
    { "name": "第四代掌柜", "if": ["c6_finale"],    "desc": "接过家徽令牌" }
  ],

  "achievements": [
    { "name": "吃货本色",   "if": ["ate_hotpot"],      "desc": "正事之前，先尝一口火锅" },
    { "name": "化敌为友",   "if": ["c2_met_labupa"],   "desc": "辣不怕成了码头上的帮手" },
    { "name": "不打不相识", "if": ["battle_B_win"],    "desc": "在招牌下亲手赢下辣不怕" },
    { "name": "一眼认祖",   "if": ["c2_e1_perfect"],   "desc": "认家徽一次没认错" },
    { "name": "舌灿莲花",   "if": ["c2_e2_perfect"],   "desc": "比口才一句没答错" },
    { "name": "颠勺满分",   "if": ["c2_e3_perfect"],   "desc": "颠勺一次没失手" },
    { "name": "毫发无伤",   "if": ["c2_ht_flawless"],  "desc": "红汤帮一战，三人都没倒下" },
    { "name": "越挫越勇",   "ifAny": ["battle_B_lose", "c2_ht_lose"], "desc": "输过一场，还是回来打赢了" },
    { "name": "新菜上桌",   "if": ["c2_dish"],         "desc": "十成椒麻秘制鸡，上了店里的菜单" },
    { "name": "星不迷眼",   "if": ["c3_e1_perfect"],   "desc": "认星位一次没认错" },
    { "name": "歌不走调",   "if": ["c3_e2_perfect"],   "desc": "对山歌一句没答错" },
    { "name": "网不落空",   "if": ["c3_e3_perfect"],   "desc": "下网一次没失手" },
    { "name": "雾中无伤",   "if": ["c3_ts_flawless"],  "desc": "铁算盘一战，三人都没倒下" },
    { "name": "夜渡抵达",   "if": ["c3_finale"],       "desc": "雾江夜渡，第三章完" },
    { "name": "年轮一眼",   "if": ["c4_e1_perfect"],   "desc": "调解一次选对依据" },
    { "name": "崖上稳脚",   "if": ["c4_e2_perfect"],   "desc": "采椒一次没失手" },
    { "name": "掌勺满分",   "if": ["c4_e3_perfect"],   "desc": "做菜一次没失手" },
    { "name": "寨中无伤",   "if": ["c4_mw_flawless"],  "desc": "麻大王一战无人倒下" },
    { "name": "麻婆岭过",   "if": ["c4_finale"],       "desc": "第四章完 · 指向红汤总舵" },
    { "name": "假账改平",   "if": ["c5_e1_perfect"],   "desc": "账房一次选对" },
    { "name": "诗句满分",   "if": ["c5_e2_perfect"],   "desc": "比诗一次全对" },
    { "name": "颠勺满分",   "if": ["c5_e3_perfect"],   "desc": "后厨一次没失手" },
    { "name": "鼎前无伤",   "if": ["c5_cl_flawless"],  "desc": "赤老三一战无人倒下" },
    { "name": "红汤楼过",   "if": ["c5_finale"],       "desc": "第五章完 · 指向天下第一锅" },
    { "name": "配方满分",   "if": ["c6_r1_perfect"],   "desc": "配方一次选对" },
    { "name": "火候满分",   "if": ["c6_r2_perfect"],   "desc": "火候一次没失手" },
    { "name": "颠勺满分·终", "if": ["c6_r3_perfect"],  "desc": "终章颠勺一次没失手" },
    { "name": "决战无伤",   "if": ["c6_cf_flawless"],  "desc": "最终战无人倒下" },
    { "name": "全文终",     "if": ["c6_finale"],       "desc": "第六章完 · 全剧终" }
  ],

  "dish": {
    "seal": "新菜解锁", "title": "十成椒麻 · 秘制鸡", "icon": "icon_recipe_full",
    "lines": ["青红二椒、汉源花椒、老鹰茶汤吊底——满家秘方，二十年后终于凑齐。",
              "满掌柜亲手掌勺，第一锅端上桌，整条街都闻得到。"],
    "reward": "店里菜单新增「十成椒麻·秘制鸡」"
  },

  "finale2": {
    "seal": "第二章完", "title": "第二章完 · 待续",
    "lines": ["半张方子，一段二十年的约定。椒麻要配茶，方子要配人。",
              "而方子背面那张藏宝图，正指向雾江上游……"],
    "next": "下一站 · 雾江古渡（店门 / 码头石阶可去）"
  },
  "finale3": {
    "seal": "第三章完", "title": "第三章完 · 待续",
    "lines": ["雾锁江心，金花椒入手。纸条上三个字——麻婆岭。",
              "阿篙撑篙北上，红汤帮的阴影却比雾更浓……"],
    "next": "下一站 · 麻婆岭花椒寨（渡船上岸山路可去）"
  },
  "feast": {
    "seal": "全寨开锅", "title": "椒麻鸡 · 寨中宴", "icon": "icon_golden_pepper",
    "lines": ["野椒下锅，土鸡翻滚。满山麻香，空碗码了一摞。",
              "老椒农说：满家的锅，没丢。"],
    "reward": "寨里记住了三个满家后人的名字"
  },
  "finale4": {
    "seal": "第四章完", "title": "第四章完 · 待续",
    "lines": ["金花椒是钥匙，赤爷藏在城里红汤总舵。",
              "麻大王改邪归正，下一程——那座终年沸腾的大酒楼。"],
    "next": "下一站 · 红汤总舵大酒楼（下山进城可去）"
  },
  "finale5": {
    "seal": "第五章完", "title": "第五章完 · 待续",
    "lines": ["旧徒赤老三，偷囊、占椒、拦船，都是他的棋。",
              "鼎边战帖朱砂未干——天下第一锅，见真章。"],
    "next": "下一站 · 渝州擂台「天下第一锅」（赴擂台可去）"
  },
  "finale": {
    "seal": "全剧终", "title": "第六章完 · 全剧终",
    "lines": ["满记夺魁。赤老三认栽，也认师。",
              "家徽令牌交到小满手里——第四代，从今晚起。",
              "铜锅重新翻滚。椒麻的香气，飘过整条街。"],
    "next": "谢谢游玩 · 《椒麻江湖》",
    "cg": "cg_ending"
  }
};
